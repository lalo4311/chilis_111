<footer>
    <div class="container">
        <nav>
            <ul class="list-menu">
                <li><a href="#">Trabaja con nosotros</a></li>
                <li><a href="#">Gift Card</a></li>
                <li><a href="#">Encuesta GEM</a></li>
                <li><a href="#">Contáctanos</a></li>
            </ul>
        </nav>
        <nav>
            <ul class="list-menu">
                <li><a href="#">Chili's</a></li>
                <li><a href="#">Mapa del sitio</a></li>
                <li><a href="#">Terminos y condiciones</a></li>
                <li><a href="#">Contáctanos</a></li>
                <li><a href="#">Contáctanos</a></li>
                <li><a href="#">Privacidad</a></li>
            </ul>
        </nav>
    </div>
</footer>



<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script type="text/javascript" src="http://cdn.jsdelivr.net/jquery.slick/1.6.0/slick.min.js"></script>
<script src="<?php bloginfo('template_directory');?>/js/bootstrap.min.js"></script>
<script>
    $(document).ready(function(){

        $('.home-slider').slick({arrows:false, autoplay:true, dots:true});

    });
</script>
</body>
</html>